<h3>Chinese-cuisine</h3>
-----------------

This folder contains the dataset and codes used in paper "Geography and similarity of regional cuisines in China". 

Please cite Yu-Xiao Zhu, Junming Huang, Zi-Ke Zhang, Qian-Ming Zhang, Tao Zhou, Yong-Yeol Ahn, Geography and similarity of regional cuisines in China, PLoS One 2013, 8(11): e79161 if you use our dataset or codes. Thanks.
Email us if you have any question. Reach me by zhuyuxiao.mail@gmail.com.

Updated by Yuxiao Zhu
03/18/2019


<h3>crawler.py</h3> 
fetch recipe data from website Meishijie(https://www.meishij.net/china-food/caixi/)
</br>
code with python, xpath

